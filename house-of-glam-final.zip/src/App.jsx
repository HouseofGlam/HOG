import React from 'react';

export default function HouseOfGlamHome() {
  return (
    <div>
      <h1>House of Glam Website Loaded</h1>
      <p>This is the base project. Replace this with your full component.</p>
    </div>
  );
}
